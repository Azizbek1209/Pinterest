# PinterestClone
This is the client of the pinterest Frontend.
If you wish to see it work with a backend, you can pull my django pinterest clone.
Install the dependencies and watch them work together, ask me questions too if you have any.
