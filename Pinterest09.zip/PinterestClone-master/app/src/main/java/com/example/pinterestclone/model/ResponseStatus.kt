package com.example.pinterestclone.model

data class ResponseStatus(
    val status: String,
)
