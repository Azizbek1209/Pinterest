package com.example.pinterestclone.model

data class Album(
    val name: String,
    val path: String,
    val id: String
)