package com.example.pinterestclone.model

data class PinObject (
    val name: String,
    val image: String?,
    val slug: String,
)
